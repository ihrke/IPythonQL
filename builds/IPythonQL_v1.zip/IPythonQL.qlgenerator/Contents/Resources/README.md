Quicklook plugin for looking at ipython notebooks
=================================================

